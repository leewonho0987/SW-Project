package client;

import client.login.Login;

public class clientcontroller {
	public static void main(String args[]) {
		Login ps = new Login();
		ps.setVisible(true);
	}
}
