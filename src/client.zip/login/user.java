package client.login;
import lombok.*;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class user {
	private String id;
	private String pw;
	private String name;
	private String Division;
	private String Block; 
}
